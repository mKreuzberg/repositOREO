import java.util.Scanner;
public class Exe03Sec06 {
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int gasolina = 0, diesel = 0, alcool = 0, x;
		System.out.println("Insira um codigo para abastecimento, sendo (1) para Alcool, (2) para Gasolina, (3) para Diesel e (4) para Sair.");
		x = sc.nextInt();
		while(x != 4){
			if(x > 4 || x < 0){
				System.out.println("Por favor, tente outro codigo.");
			}else if(x == 1){
				alcool += 1;
			}else if(x == 2){
				gasolina += 1;
			}else if(x == 3){
				diesel += 1;
			}
			x = sc.nextInt();
		}
		System.out.println("MUITO OBRIGADO");
		System.out.println("Alcool: " + alcool);
		System.out.println("Gasolina: " + gasolina);
		System.out.println("Diesel: " + diesel);
		sc.close();
	}
}