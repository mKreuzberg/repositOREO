import java.util.Scanner;
import java.util.Locale;
public class Exe05Sec05 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Locale.setDefault(Locale.US);
		Scanner sc = new Scanner(System.in);
		int codigo, quantidade;
		double cod1 = 4.00, cod2 = 4.50, cod3 = 5.00, cod4 = 2.00, cod5 = 1.50, total;
		codigo = sc.nextInt();
		quantidade = sc.nextInt();
		if(codigo == 1){
			total = quantidade * cod1;
			System.out.printf("Total: R$ %.2f%n", total);
		}
		else if(codigo == 2){
			total = quantidade * cod2;
			System.out.printf("Total: R$ %.2f%n", total);
		}
		else if(codigo == 3){
			total = quantidade * cod3;
			System.out.printf("Total: R$ %.2f%n", total);
		}
		else if(codigo == 4){
			total = quantidade * cod4;
			System.out.printf("Total: R$ %.2f%n", total);
		}
		else if(codigo == 5){
			total = quantidade * cod5;
			System.out.printf("Total: R$ %.2f%n", total);
		}
		sc.close();
	}

}
