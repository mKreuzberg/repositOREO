import java.util.Scanner;
public class Exe03Sec04 {	
	public static void main(String[] args) {
		int a, b, c, d, e;Scanner sc = new Scanner(System.in);		
		a = sc.nextInt();b = sc.nextInt();c = sc.nextInt();d = sc.nextInt();e = a*b-c*d;
		System.out.println("diferenca: "+e);		
		sc.close();
	}
}