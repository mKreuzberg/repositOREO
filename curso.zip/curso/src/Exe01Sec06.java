import java.util.Scanner;
public class Exe01Sec06 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Exercicio 01");
		
		int senha = 2002, digito=0;
		digito = sc.nextInt();
		while(digito != senha){
			System.out.println("Senha Incorreta!");
			digito = sc.nextInt();
		}
		System.out.println("Acesso Permitido");
		sc.close();

	}

}