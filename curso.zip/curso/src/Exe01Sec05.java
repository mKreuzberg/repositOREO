import java.util.Scanner;



public class Exe01Sec05 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int a;
		System.out.println("Digite um Numero: ");
		a = sc.nextInt();
		if (a >= 0){
			System.out.println("NAO NEGATIVO!");
		}
		else{
			System.out.println("NEGATIVO!");
		}
		sc.close();
	}

}
