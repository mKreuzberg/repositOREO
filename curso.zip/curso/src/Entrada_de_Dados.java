import java.util.Scanner;
public class Entrada_de_Dados {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String x;
		System.out.println("Digita qualquer carai ae: ");
		x = sc.next();
		System.out.println("Tu digitou: "+x);
		
		
		sc.close();
	}

}
