import java.util.Scanner;
import java.util.Locale;

public class Exe05Sec04 {
	
	public static void main(String[] args) {
		Locale.setDefault(Locale.US);
		Scanner sc = new Scanner(System.in);
		int codP1, np1, codP2, np2; double vup1, vup2, tot1, tot2, vt;
		codP1 = sc.nextInt();
		np1 = sc.nextInt();
		vup1 = sc.nextDouble();
		codP2 = sc.nextInt();
		np2 = sc.nextInt();
		vup2 = sc.nextDouble();
		
		tot1 = np1 * vup1; tot2 = np2 * vup2; vt = tot1 + tot2;
		
		System.out.printf("VALOR A PAGAR = U$ %.2f%n", vt);
		sc.close();
	}

}
