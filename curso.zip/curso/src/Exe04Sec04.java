import java.util.Locale;
import java.util.Scanner;
public class Exe04Sec04 {
	public static void main(String[] args) {
		Locale.setDefault(Locale.US);
		Scanner sc = new Scanner(System.in);		
		int numeroFuncionario, numHorasTrab; 
		double valorHorasTrab, result;		
		numeroFuncionario = sc.nextInt();
		numHorasTrab = sc.nextInt();
		valorHorasTrab = sc.nextDouble();		
		result = valorHorasTrab*numHorasTrab;		
		System.out.println("NUMBER = " + numeroFuncionario);
		System.out.printf("SALARY = U$ %.2f%n", result);
		
		
		sc.close();
	}

}
