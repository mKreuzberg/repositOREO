import java.util.Scanner;
public class Exe04Sec05 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int a, b, c;
		a = sc.nextInt();
		b = sc.nextInt();
		if(a < b){
			c = a - b;
		}else {
			c = 24 - a + b;
		}
		System.out.println("O JOGO DUROS " + c + " HORAS.");
		sc.close();
	}

}
