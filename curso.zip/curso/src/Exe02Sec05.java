import java.util.Scanner;
public class Exe02Sec05 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int a;
		System.out.println("Digite: ");
		a = sc.nextInt();
		if(a % 2 == 0){
			System.out.println("par");
		}
		else{
			System.out.println("impar");
		}
		sc.close();
	}
		
}
