import java.util.Scanner;
public class Exe01Sec04 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int x;
		int y;
		int result;
		System.out.println("Digite o primeiro valor: ");
		x = sc.nextInt();
		System.out.println("Digite o segundo valor: ");
		y = sc.nextInt();
		result = x + y;
		System.out.println("O resultado eh: " + result);
		
	}

}
